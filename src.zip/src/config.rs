// config.rs — Runtime configuration.
//
// Priority (highest → lowest):
// 1. Environment variables (CHAN_BIND, CHAN_DB, …)
// 2. settings.toml (<exe-dir>/rustchan-data/settings.toml)
// 3. Hard-coded defaults
//
// On first run, settings.toml is generated next to the binary with all
// default values and explanatory comments. Edit it, restart the server.
//
// SECURITY: The cookie_secret is auto-generated on first run and persisted
// to settings.toml. It is never left at a well-known default value.
use rand_core::{OsRng, RngCore};
use serde::Deserialize;
use std::env;
use std::path::PathBuf;
use std::sync::LazyLock;

/// Absolute path to the directory the running binary lives in.
fn binary_dir() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(std::path::Path::to_path_buf))
        .unwrap_or_else(|| {
            eprintln!(
                "Warning: could not determine binary directory; \
                 using current working directory for data storage. \
                 Set CHAN_DB and CHAN_UPLOADS env vars to override."
            );
            PathBuf::from(".")
        })
}

fn settings_file_path() -> PathBuf {
    // Store settings.toml in rustchan-data/ alongside the database.
    // rustchan-data/ is created by run_server before CONFIG is first accessed,
    // so this directory always exists by the time settings are read.
    let data_dir = binary_dir().join("rustchan-data");
    data_dir.join("settings.toml")
}

// ─── Settings file structure ──────────────────────────────────────────────────
#[derive(Deserialize, Default)]
struct SettingsFile {
    forum_name: Option<String>,
    /// Home page subtitle shown below the site name.
    site_subtitle: Option<String>,
    /// Default theme served to first-time visitors before they pick one.
    /// Valid values: terminal, aero, dorfic, fluorogrid, neoncubicle, chanclassic
    default_theme: Option<String>,
    port: Option<u16>,
    max_image_size_mb: Option<u32>,
    max_video_size_mb: Option<u32>,
    max_audio_size_mb: Option<u32>,
    cookie_secret: Option<String>,
    enable_tor_support: Option<bool>,
    /// When true, the HTTP server binds exclusively to 127.0.0.1 so it is
    /// reachable only through the Tor hidden service. Overrides the host
    /// portion of `bind_addr` (the configured port is preserved).
    /// Default: false (clearnet and Tor both active when `enable_tor_support=true`).
    tor_only: Option<bool>,
    /// Seconds to wait for Tor bootstrap before timing out and retrying.
    /// Increase to 300+ on heavily censored networks or when using bridges.
    /// Default: 120.
    tor_bootstrap_timeout_secs: Option<u64>,
    /// Maximum simultaneous inbound Tor streams (proxy tasks).
    /// Each stream holds one file descriptor. Reduce if the process runs low
    /// on FDs; excess connections are dropped with a `RELAY_END` cell.
    /// Default: 512.
    tor_max_concurrent_streams: Option<usize>,
    /// Nickname for the Arti onion service key.
    /// Must be unique per `arti_state/` directory. Change this when running
    /// multiple instances that share the same storage to avoid key collisions.
    /// Default: "rustchan".
    tor_service_nickname: Option<String>,
    require_ffmpeg: Option<bool>,
    /// How often to run PRAGMA `wal_checkpoint(TRUNCATE)`, in seconds.
    /// Set to 0 to disable. Default: 3600 (hourly).
    wal_checkpoint_interval_secs: Option<u64>,
    /// How often to run VACUUM to reclaim disk space, in hours.
    /// Set to 0 to disable. Default: 24 (daily).
    auto_vacuum_interval_hours: Option<u64>,
    /// How often to purge vote records for expired polls, in hours.
    /// Set to 0 to disable. Default: 72 (every 3 days).
    poll_cleanup_interval_hours: Option<u64>,
    /// Database file size (MB) above which a warning banner is shown in the
    /// admin panel. Set to 0 to disable. Default: 2048 (2 GiB).
    db_warn_threshold_mb: Option<u64>,
    /// Maximum number of pending jobs in the background job queue.
    /// When this limit is reached, new jobs are dropped (with a warning) rather
    /// than accepted. Default: 1000.
    job_queue_capacity: Option<u64>,
    /// Maximum seconds to allow a single `FFmpeg` transcode or waveform job to
    /// run before it is killed. Default: 120.
    ffmpeg_timeout_secs: Option<u64>,
    /// When true, overflow threads are always archived rather than hard-deleted,
    /// even on boards with `allow_archive` = false. Default: true.
    archive_before_prune: Option<bool>,
    /// Maximum total size (MiB) of all thumbnail/waveform cache files across all
    /// boards. A background task evicts the oldest files when exceeded.
    /// Set to 0 to disable. Default: 200.
    waveform_cache_max_mb: Option<u64>,
    /// Number of threads in Tokio's blocking pool (`spawn_blocking`).
    /// Defaults to logical CPUs × 4. Increase if DB/render latency is a bottleneck
    /// under load.
    blocking_threads: Option<usize>,
    /// `SQLite` connection pool size. Default: 8.
    /// Increase on high-traffic deployments; each connection uses ~32 MiB page cache.
    db_pool_size: Option<u32>,
    // ── ChanNet / RustWave gateway ────────────────────────────────────────────
    /// Base URL of the connected `RustWave` instance.
    /// Must begin with http:// or https://. Default: <http://localhost:7071>.
    rustwave_url: Option<String>,
    /// Address to bind the second `ChanNet` TCP listener.
    /// Default: 127.0.0.1:7070 (loopback-only; not exposed to the internet).
    chan_net_bind: Option<String>,
    /// Pre-shared API key required for /chan/refresh and /chan/poll endpoints.
    /// Must be at least 32 characters. Leave empty to disable the endpoints.
    /// Set via `CHAN_NET_API_KEY` environment variable or `settings.toml`.
    chan_net_api_key: Option<String>,
    /// TLS/HTTPS configuration. Omitting this section keeps TLS disabled.
    tls: Option<TlsConfig>,
}

fn load_settings_file() -> SettingsFile {
    let path = settings_file_path();
    let Ok(raw) = std::fs::read_to_string(&path) else {
        return SettingsFile::default();
    };
    toml::from_str(&raw).unwrap_or_else(|e| {
        eprintln!("Warning: could not parse settings.toml: {e}");
        SettingsFile::default()
    })
}

/// Create settings.toml with defaults if it does not exist yet.
/// Call this once at startup (before CONFIG is accessed for the first time).
///
/// A cryptographically random `cookie_secret` is generated on first run and
/// written to settings.toml. Subsequent runs load it from the file.
/// The server never operates with a known/default secret.
pub fn generate_settings_file_if_missing() {
    let path = settings_file_path();
    if path.exists() {
        return;
    }
    // Generate a random 64-hex-char secret (32 bytes of entropy).
    let mut secret_bytes = [0u8; 32];
    OsRng.fill_bytes(&mut secret_bytes);
    let secret = hex::encode(secret_bytes);
    let content = settings_template(&secret);
    match std::fs::write(&path, content) {
        Ok(()) => println!("Created settings.toml ({})", path.display()),
        Err(e) => eprintln!("Warning: could not write settings.toml: {e}"),
    }
}

/// Build the default settings.toml content with the given generated secret.
///
/// Extracted from `generate_settings_file_if_missing` to keep that function
/// under the line-count lint threshold.
fn settings_template(secret: &str) -> String {
    format!(
        r#"# RustChan — Instance Settings
# Edit this file to configure your imageboard.
# Restart the server after making changes.
# Name shown in the browser tab, page header, and home page title.
forum_name = "RustChan"
# Subtitle shown below the site name on the home page.
# Can also be changed at any time from the admin panel → Site Settings.
site_subtitle = "select board to proceed"
# Default theme for first-time visitors (before they choose their own).
# Valid values: terminal, aero, dorfic, fluorogrid, neoncubicle, chanclassic
# Leave as "terminal" (or empty) for the default dark terminal look.
# Can also be changed at any time from the admin panel → Site Settings.
default_theme = "terminal"
# Port the server listens on (binds to 0.0.0.0:<port>).
port = 8080
# Maximum size for image uploads in megabytes (jpg, png, gif, webp).
max_image_size_mb = 8
# Maximum size for video uploads in megabytes (mp4, webm).
max_video_size_mb = 50
# Maximum size for audio uploads in megabytes (mp3, ogg, flac, wav, m4a, aac).
max_audio_size_mb = 150
{server_section}
# Secret key for IP hashing.
# AUTO-GENERATED on first run — do NOT change after your first post,
# or all existing IP hashes become invalid (bans will stop working).
# If you must rotate it, also clear the bans table.
cookie_secret = "{secret}"
# ── ChanNet / RustWave gateway ────────────────────────────────────────────────
# Uncomment and configure these to enable the ChanNet API (--chan-net flag).
# Base URL of the connected RustWave instance.
# Must begin with http:// or https://.
# rustwave_url = "http://localhost:7071"
# Address to bind the second ChanNet TCP listener.
# Keep on loopback unless RustWave runs on a different host.
# chan_net_bind = "127.0.0.1:7070"
{tls_section}"#,
        server_section = settings_template_server_section(),
        tls_section = settings_template_tls_section(),
    )
}

/// Tor, `FFmpeg`, maintenance, and worker settings portion of the default
/// settings template.
///
/// Extracted from [`settings_template`] to keep all functions under the
/// line-count lint threshold.
const fn settings_template_server_section() -> &'static str {
    r#"
# Tor Onion Service support (powered by Arti — no system tor required).
# When true, Arti bootstraps at startup and hosts a .onion hidden service.
# First run downloads ~2 MB of directory data and takes ~30 s.
# The service keypair lives in rustchan-data/arti_state/keys/ — back it up.
# Delete that directory to rotate to a new .onion address.
enable_tor_support = true
# When true, the HTTP server binds exclusively to 127.0.0.1 so the site is
# reachable ONLY through the Tor hidden service — clearnet access is blocked.
# Requires enable_tor_support = true. Default: false (dual-stack: both
# clearnet and Tor are active simultaneously).
# tor_only = false
# Seconds to wait for Tor to connect to the network before giving up and
# retrying. The default (120 s) works on open networks. On censored networks
# or when using bridges, increase this to 300 or more.
# tor_bootstrap_timeout_secs = 120
# Maximum number of simultaneous inbound Tor connections.
# Each connection holds one file descriptor. Reduce if you hit FD limits.
# tor_max_concurrent_streams = 512
# Nickname for this instance's Tor hidden service key.
# Only needs changing when multiple rustchan instances share the same
# rustchan-data/arti_state/ directory — identical nicknames cause key
# collisions and one instance will fail to start its onion service.
# tor_service_nickname = "rustchan"
# Set to true to hard-exit at startup when ffmpeg is not found.
# When false (default), the server starts normally and video thumbnails
# are replaced with SVG placeholders.
require_ffmpeg = false
# How often (in seconds) to run PRAGMA wal_checkpoint(TRUNCATE) to keep
# the SQLite WAL file from growing unbounded under write load.
# Set to 0 to disable. Default: 3600 (hourly).
wal_checkpoint_interval_secs = 3600
# How often (in hours) to run VACUUM automatically to reclaim disk space
# freed by deleted posts and threads. Set to 0 to disable. Default: 24.
auto_vacuum_interval_hours = 24
# How often (in hours) to purge vote records for polls that have expired.
# The poll question and options are kept for display; only per-IP vote rows
# are deleted. Set to 0 to disable. Default: 72.
poll_cleanup_interval_hours = 72
# Database file size (MiB) above which a warning banner appears in the admin
# panel. Set to 0 to disable. Default: 2048 (2 GiB).
db_warn_threshold_mb = 2048
# Maximum number of pending background jobs (video transcode, waveform, etc.)
# allowed in the queue at once. When this limit is reached, new jobs are
# silently dropped (with a warning log) rather than accepted. Default: 1000.
job_queue_capacity = 1000
# Maximum seconds a single FFmpeg transcode or waveform job may run before
# it is killed. Prevents pathological media files from stalling the worker
# pool indefinitely. Default: 120.
ffmpeg_timeout_secs = 120
# When true, threads that would be hard-deleted by the prune worker are instead
# moved to the archive table, even on boards where archiving is disabled. This
# acts as a global safety net against silent data loss when a board hits its
# thread limit. Default: true.
archive_before_prune = true
# Maximum total size (MiB) of all thumbnail/waveform cache files across all
# boards. A background task periodically evicts the oldest files when the
# total exceeds this value. Set to 0 to disable. Default: 200.
waveform_cache_max_mb = 200
# Number of threads in Tokio's blocking pool (spawn_blocking). Every page
# render and DB write goes through this pool; sizing it to CPUs × 4 prevents
# it from becoming a bottleneck under concurrent load.
# Default: logical CPUs × 4 (auto-detected at startup; leave 0 for auto).
blocking_threads = 0
"#
}

/// TLS/HTTPS portion of the default settings template.
///
/// Extracted from [`settings_template`] to keep both functions under the
/// line-count lint threshold.
const fn settings_template_tls_section() -> &'static str {
    r#"
# ── TLS / HTTPS ───────────────────────────────────────────────────────────────
# HTTPS is enabled by default on port 8443. On first run a self-signed
# localhost certificate is generated automatically in rustchan-data/tls/dev/.
# For production, configure [tls.acme] (Let's Encrypt) or [tls.manual_cert].
[tls]
enabled = true
port = 8443
# Redirect plain HTTP → HTTPS (binds an extra listener on http_port).
# redirect_http = true
# http_port = 8080
# Let's Encrypt via ACME (requires the tls-acme Cargo feature):
# [tls.acme]
# enabled = true
# staging = true
# domains = ["example.com"]
# email = "admin@example.com"
# cache_dir = "tls/acme"
"#
}

// ─── TLS configuration ───────────────────────────────────────────────────────
#[derive(Debug, Clone, serde::Deserialize)]
pub struct TlsConfig {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default = "default_https_port")]
    pub port: u16,
    #[serde(default)]
    pub redirect_http: bool,
    #[serde(default = "default_http_port")]
    pub http_port: u16,
    #[serde(default)]
    pub acme: AcmeConfig,
    pub manual_cert: Option<ManualCertConfig>,
}

impl Default for TlsConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            port: default_https_port(),
            redirect_http: false,
            http_port: default_http_port(),
            acme: AcmeConfig::default(),
            manual_cert: None,
        }
    }
}

#[derive(Debug, Clone, serde::Deserialize, Default)]
pub struct AcmeConfig {
    #[serde(default)]
    pub enabled: bool,

    // These fields are only read when the `tls-acme` Cargo feature is enabled
    // (the Let's Encrypt implementation lives in a separate module).
    // They are intentionally kept here so the `[tls.acme]` section in
    // settings.toml deserializes cleanly even when the feature is off.
    #[serde(default)]
    #[allow(dead_code)]
    pub domains: Vec<String>,
    #[serde(default)]
    #[allow(dead_code)]
    pub email: Option<String>,
    #[serde(default = "default_true")]
    #[allow(dead_code)]
    pub staging: bool,
    #[serde(default = "default_acme_dir")]
    #[allow(dead_code)]
    pub cache_dir: String,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct ManualCertConfig {
    pub cert_path: String,
    pub key_path: String,
}

const fn default_https_port() -> u16 {
    8443
}

const fn default_http_port() -> u16 {
    8080
}

const fn default_true() -> bool {
    true
}

fn default_acme_dir() -> String {
    "tls/acme".into()
}

// ─── Runtime config ───────────────────────────────────────────────────────────
pub static CONFIG: LazyLock<Config> = LazyLock::new(Config::from_env);

#[allow(clippy::struct_excessive_bools)]
pub struct Config {
    // ── Loaded from settings.toml (env vars still override) ──────────────────
    pub forum_name: String,
    /// Initial subtitle shown on the home page (seeds the DB on first run).
    pub initial_site_subtitle: String,
    /// Initial default theme slug (seeds the DB on first run).
    /// Valid: terminal, aero, dorfic, fluorogrid, neoncubicle, chanclassic
    pub initial_default_theme: String,
    #[allow(dead_code)] // read by CLI subcommands and printed at startup
    pub port: u16,
    pub max_image_size: usize, // bytes
    pub max_video_size: usize, // bytes
    pub max_audio_size: usize, // bytes,
    // ── External tool settings ────────────────────────────────────────────────
    /// When true, Tor is probed at startup and hints are printed.
    pub enable_tor_support: bool,
    /// When true, the server binds to loopback only and is reachable exclusively
    /// via the Tor hidden service. Requires `enable_tor_support = true`.
    pub tor_only: bool,
    /// Seconds before a bootstrap attempt is considered failed and retried.
    pub tor_bootstrap_timeout_secs: u64,
    /// Maximum simultaneous inbound Tor proxy tasks.
    pub tor_max_concurrent_streams: usize,
    /// Nickname for the Arti onion service. Unique per `arti_state/` directory.
    pub tor_service_nickname: String,
    /// When true, the server exits if ffmpeg is missing.
    pub require_ffmpeg: bool,
    // ── Internal / env-only settings ─────────────────────────────────────────
    pub bind_addr: String,
    pub database_path: String,
    pub upload_dir: String,
    pub thumb_size: u32,
    #[allow(dead_code)] // used as default when creating boards via CLI/admin
    pub default_bump_limit: u32,
    #[allow(dead_code)] // used as default when creating boards via CLI/admin
    pub max_threads_per_board: u32,
    /// Maximum GET requests per IP per `rate_limit_window`.
    pub rate_limit_gets: u32,
    pub rate_limit_window: u64,
    pub cookie_secret: String,
    pub session_duration: i64,
    pub behind_proxy: bool,
    pub https_cookies: bool,
    /// Interval in seconds between WAL checkpoint runs. 0 = disabled.
    pub wal_checkpoint_interval: u64,
    /// Interval in hours between automatic VACUUM runs. 0 = disabled.
    pub auto_vacuum_interval_hours: u64,
    /// Interval in hours between expired poll vote cleanup runs. 0 = disabled.
    pub poll_cleanup_interval_hours: u64,
    /// DB file size threshold in bytes above which admin panel shows a warning.
    /// 0 = disabled.
    pub db_warn_threshold_bytes: u64,
    /// Maximum number of pending jobs before new ones are dropped.
    pub job_queue_capacity: u64,
    /// Maximum seconds a single `FFmpeg` job may run before being killed.
    pub ffmpeg_timeout_secs: u64,
    /// When true, threads are always archived (never hard-deleted) on prune,
    /// overriding individual board settings.
    pub archive_before_prune: bool,
    /// Total thumbnail/waveform cache size limit in bytes. 0 = disabled.
    pub waveform_cache_max_bytes: u64,
    /// Number of threads in Tokio's blocking pool. Default: logical CPUs × 4.
    pub blocking_threads: usize,
    /// `SQLite` `r2d2` connection pool size (default 8).
    pub db_pool_size: u32,
    // ── ChanNet / RustWave gateway (Step 1.2) ────────────────────────────────
    /// Base URL of the connected `RustWave` instance (must begin with http:// or https://).
    /// Validated at startup by `Config::validate()`.
    pub rustwave_url: String,
    /// Address to bind the second `ChanNet` TCP listener (default 127.0.0.1:7070).
    /// Only used when the server is started with `--chan-net`.
    pub chan_net_bind: String,
    /// Maximum request body size for `/chan/import` (ZIP snapshots). Default: 10 MiB.
    pub chan_net_max_body: usize,
    /// Maximum request body size for `/chan/command` (raw JSON). Default: 8 KiB.
    pub chan_net_command_max_body: usize,
    /// Pre-shared key required on X-ChanNet-Key header for /chan/refresh and
    /// /chan/poll. An empty string means those endpoints are disabled entirely.
    pub chan_net_api_key: String,
    // ── TLS / HTTPS ───────────────────────────────────────────────────────────
    /// TLS configuration. Defaults to disabled so existing installs are unaffected.
    pub tls: TlsConfig,
}

impl Config {
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn from_env() -> Self {
        let s = load_settings_file();
        let data_dir = binary_dir().join("rustchan-data");
        let default_db = data_dir.join("chan.db").to_string_lossy().into_owned();
        let default_uploads = data_dir.join("boards").to_string_lossy().into_owned();
        let forum_name = env_str(
            "CHAN_FORUM_NAME",
            s.forum_name.as_deref().unwrap_or("RustChan"),
        );
        let initial_site_subtitle = env_str(
            "CHAN_SITE_SUBTITLE",
            s.site_subtitle
                .as_deref()
                .unwrap_or("select board to proceed"),
        );
        let initial_default_theme = env_str(
            "CHAN_DEFAULT_THEME",
            s.default_theme.as_deref().unwrap_or("terminal"),
        );
        let port: u16 = env_parse("CHAN_PORT", s.port.unwrap_or(8080));
        let max_image_mb: u32 = env_parse("CHAN_MAX_IMAGE_MB", s.max_image_size_mb.unwrap_or(8));
        let max_video_mb: u32 = env_parse("CHAN_MAX_VIDEO_MB", s.max_video_size_mb.unwrap_or(50));
        let max_audio_mb: u32 = env_parse("CHAN_MAX_AUDIO_MB", s.max_audio_size_mb.unwrap_or(150));
        let bind_addr = env_str(
            "CHAN_BIND",
            &format!("{}:{}", env_str("CHAN_HOST", "0.0.0.0"), port),
        );
        let tor_only = env_bool("CHAN_TOR_ONLY", s.tor_only.unwrap_or(false));
        let enable_tor_support = env_bool("CHAN_TOR_SUPPORT", s.enable_tor_support.unwrap_or(true));
        // When tor_only=true, force the bind host to 127.0.0.1 regardless of
        // what bind_addr or CHAN_HOST are set to. The configured port is kept.
        let bind_addr = if tor_only && enable_tor_support {
            let port_str = bind_addr.rsplit_once(':').map_or("8080", |(_, p)| p);
            tracing::info!(
                target: "config",
                bind_addr = %format!("127.0.0.1:{port_str}"),
                "tor_only=true: overriding bind address to loopback"
            );
            format!("127.0.0.1:{port_str}")
        } else {
            bind_addr
        };
        let behind_proxy = env_bool("CHAN_BEHIND_PROXY", false);
        // Resolve cookie_secret from env > settings.toml.
        // generate_settings_file_if_missing() ensures settings.toml always has
        // a generated secret, so this fallback should only fire in abnormal cases.
        let cookie_secret = if let Ok(v) = env::var("CHAN_COOKIE_SECRET") {
            v
        } else if let Some(v) = s.cookie_secret {
            v
        } else {
            eprintln!(
                "SECURITY WARNING: No cookie_secret found in environment or settings.toml. \
                 IP hashing is using an empty secret. Run the server once to auto-generate, \
                 or set CHAN_COOKIE_SECRET."
            );
            // Random in-memory secret so each restart invalidates hashes
            // (better than a known empty string, worse than a persisted one).
            let mut b = [0u8; 32];
            OsRng.fill_bytes(&mut b);
            hex::encode(b)
        };
        // ── ChanNet fields (Step 1.2) — computed after cookie_secret ──────────
        // Use as_deref() to borrow rather than move the Option<String> fields.
        let rustwave_url = env::var("CHAN_RUSTWAVE_URL").unwrap_or_else(|_| {
            s.rustwave_url
                .as_deref()
                .unwrap_or("http://localhost:7071")
                .to_string()
        });
        let chan_net_bind = env::var("CHAN_NET_BIND").unwrap_or_else(|_| {
            s.chan_net_bind
                .as_deref()
                .unwrap_or("127.0.0.1:7070")
                .to_string()
        });
        let chan_net_max_body: usize = env::var("CHAN_NET_MAX_BODY")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(10 * 1024 * 1024); // 10 MiB default
        let chan_net_command_max_body: usize = env::var("CHAN_NET_COMMAND_MAX_BODY")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(8 * 1024); // 8 KiB default — commands are raw JSON, never ZIPs
        Self {
            forum_name,
            initial_site_subtitle,
            initial_default_theme,
            port,
            max_image_size: (max_image_mb as usize)
                .saturating_mul(1024)
                .saturating_mul(1024),
            max_video_size: (max_video_mb as usize)
                .saturating_mul(1024)
                .saturating_mul(1024),
            max_audio_size: (max_audio_mb as usize)
                .saturating_mul(1024)
                .saturating_mul(1024),
            enable_tor_support,
            tor_only: tor_only && enable_tor_support,
            tor_bootstrap_timeout_secs: env_parse(
                "CHAN_TOR_BOOTSTRAP_TIMEOUT",
                s.tor_bootstrap_timeout_secs.unwrap_or(120),
            ),
            tor_max_concurrent_streams: env_parse(
                "CHAN_TOR_MAX_STREAMS",
                s.tor_max_concurrent_streams.unwrap_or(512),
            ),
            tor_service_nickname: std::env::var("CHAN_TOR_NICKNAME")
                .ok()
                .or(s.tor_service_nickname)
                .unwrap_or_else(|| "rustchan".to_string()),
            require_ffmpeg: env_bool("CHAN_REQUIRE_FFMPEG", s.require_ffmpeg.unwrap_or(false)),
            bind_addr,
            database_path: env_str("CHAN_DB", &default_db),
            upload_dir: env_str("CHAN_UPLOADS", &default_uploads),
            thumb_size: env_parse("CHAN_THUMB_SIZE", 250),
            default_bump_limit: env_parse("CHAN_BUMP_LIMIT", 500),
            max_threads_per_board: env_parse("CHAN_MAX_THREADS", 150),
            rate_limit_gets: env_parse("CHAN_RATE_GETS", 60),
            rate_limit_window: env_parse("CHAN_RATE_WINDOW", 60),
            cookie_secret,
            session_duration: env_parse("CHAN_SESSION_SECS", 8 * 3600),
            behind_proxy,
            https_cookies: env_bool("CHAN_HTTPS_COOKIES", behind_proxy),
            wal_checkpoint_interval: env_parse(
                "CHAN_WAL_CHECKPOINT_SECS",
                s.wal_checkpoint_interval_secs.unwrap_or(3600),
            ),
            auto_vacuum_interval_hours: env_parse(
                "CHAN_AUTO_VACUUM_HOURS",
                s.auto_vacuum_interval_hours.unwrap_or(24),
            ),
            poll_cleanup_interval_hours: env_parse(
                "CHAN_POLL_CLEANUP_HOURS",
                s.poll_cleanup_interval_hours.unwrap_or(72),
            ),
            db_warn_threshold_bytes: {
                let mb = env_parse::<u64>(
                    "CHAN_DB_WARN_THRESHOLD_MB",
                    s.db_warn_threshold_mb.unwrap_or(2048),
                );
                mb.saturating_mul(1024).saturating_mul(1024)
            },
            job_queue_capacity: env_parse(
                "CHAN_JOB_QUEUE_CAPACITY",
                s.job_queue_capacity.unwrap_or(1000),
            ),
            ffmpeg_timeout_secs: env_parse(
                "CHAN_FFMPEG_TIMEOUT_SECS",
                s.ffmpeg_timeout_secs.unwrap_or(120),
            ),
            archive_before_prune: env_bool(
                "CHAN_ARCHIVE_BEFORE_PRUNE",
                s.archive_before_prune.unwrap_or(true),
            ),
            waveform_cache_max_bytes: {
                let mb = env_parse::<u64>(
                    "CHAN_WAVEFORM_CACHE_MAX_MB",
                    s.waveform_cache_max_mb.unwrap_or(200),
                );
                mb.saturating_mul(1024).saturating_mul(1024)
            },
            blocking_threads: {
                let cpus = std::thread::available_parallelism()
                    .map(std::num::NonZero::get)
                    .unwrap_or(4);
                let configured =
                    env_parse("CHAN_BLOCKING_THREADS", s.blocking_threads.unwrap_or(0));
                if configured == 0 {
                    cpus.saturating_mul(4)
                } else {
                    configured
                }
            },
            db_pool_size: env_parse("CHAN_DB_POOL_SIZE", s.db_pool_size.unwrap_or(8)),
            // ChanNet fields
            rustwave_url,
            chan_net_bind,
            chan_net_max_body,
            chan_net_command_max_body,
            chan_net_api_key: std::env::var("CHAN_NET_API_KEY")
                .ok()
                .or(s.chan_net_api_key)
                .unwrap_or_default(),
            // TLS — loaded from [tls] section in settings.toml; defaults to disabled.
            tls: s.tls.unwrap_or_default(),
        }
    }

    /// Validate critical configuration values and abort with a clear error
    /// message if any are out of range. Called once at startup so operators
    /// catch misconfiguration immediately rather than discovering it at runtime.
    ///
    /// # Errors
    /// Returns an error if any configuration value is out of an acceptable range,
    /// or if the upload directory is not writable.
    pub fn validate(&self) -> anyhow::Result<()> {
        const MIB: usize = 1024 * 1024;
        const MAX_IMAGE_MIB: usize = 100;
        const MAX_VIDEO_MIB: usize = 2048;
        const MAX_AUDIO_MIB: usize = 512;
        // cookie_secret is hex-encoded: 64 hex chars = 32 bytes of entropy.
        if self.cookie_secret.len() < 64 {
            anyhow::bail!(
                "CONFIG ERROR: cookie_secret is too short ({} chars). \
                 It must be at least 64 hex characters (32 bytes). \
                 Delete settings.toml and restart to auto-generate a secure secret.",
                self.cookie_secret.len()
            );
        }
        if self.max_image_size < MIB || self.max_image_size > MAX_IMAGE_MIB * MIB {
            anyhow::bail!(
                "CONFIG ERROR: max_image_size_mb must be between 1 and {} MiB (got {} MiB).",
                MAX_IMAGE_MIB,
                self.max_image_size / MIB
            );
        }
        if self.max_video_size < MIB || self.max_video_size > MAX_VIDEO_MIB * MIB {
            anyhow::bail!(
                "CONFIG ERROR: max_video_size_mb must be between 1 and {} MiB (got {} MiB).",
                MAX_VIDEO_MIB,
                self.max_video_size / MIB
            );
        }
        if self.max_audio_size < MIB || self.max_audio_size > MAX_AUDIO_MIB * MIB {
            anyhow::bail!(
                "CONFIG ERROR: max_audio_size_mb must be between 1 and {} MiB (got {} MiB).",
                MAX_AUDIO_MIB,
                self.max_audio_size / MIB
            );
        }
        if self.port == 0 {
            anyhow::bail!("CONFIG ERROR: port must not be 0.");
        }
        if self.tls.enabled && self.tls.port == 0 {
            anyhow::bail!(
                "CONFIG ERROR: tls.port must not be 0. \
                 Add `port = 8443` under [tls] in settings.toml, or remove the explicit `port = 0`."
            );
        }
        // Verify the upload directory is writable.
        let upload_path = std::path::Path::new(&self.upload_dir);
        if upload_path.exists() {
            let probe = upload_path.join(".write_probe");
            if std::fs::write(&probe, b"").is_err() {
                anyhow::bail!(
                    "CONFIG ERROR: upload_dir '{}' is not writable.",
                    self.upload_dir
                );
            }
            let _ = std::fs::remove_file(probe);
        }
        // F-13: Pre-flight writability check for Arti data directories.
        // Without this, a permissions error on these dirs only surfaces ~30 s
        // into bootstrap as a cryptic internal error — invisible at startup.
        if self.enable_tor_support {
            let exe = std::env::current_exe()
                .ok()
                .and_then(|p| p.parent().map(std::path::Path::to_path_buf))
                .unwrap_or_else(|| std::path::PathBuf::from("."));
            let data_dir = exe.join("rustchan-data");
            for subdir in ["arti_state", "arti_cache"] {
                let dir = data_dir.join(subdir);
                std::fs::create_dir_all(&dir).map_err(|e| {
                    anyhow::anyhow!("CONFIG ERROR: cannot create Tor dir {}: {e}", dir.display())
                })?;
                // Arti requires arti_state/ to have permissions 0700 (no group
                // or other read access) for its key material. create_dir_all
                // respects the process umask, typically yielding 0755, which
                // Arti rejects with "problem with filesystem permissions".
                // Explicitly set 0700 on Unix so Arti accepts the directory.
                // arti_cache/ holds no sensitive data and is left at normal
                // permissions, but we restrict it too for defence-in-depth.
                #[cfg(unix)]
                {
                    use std::os::unix::fs::PermissionsExt;
                    let perms = std::fs::Permissions::from_mode(0o700);
                    std::fs::set_permissions(&dir, perms).map_err(|e| {
                        anyhow::anyhow!(
                            "CONFIG ERROR: cannot set permissions on Tor dir {}: {e}",
                            dir.display()
                        )
                    })?;
                }
                let probe = dir.join(".write_probe");
                std::fs::write(&probe, b"").map_err(|_| {
                    anyhow::anyhow!(
                        "CONFIG ERROR: Tor dir {} is not writable — check permissions",
                        dir.display()
                    )
                })?;
                let _ = std::fs::remove_file(probe);
            }
        }
        // Step 1.2: Validate rustwave_url scheme so operators catch
        // misconfiguration at startup rather than at first federation call.
        if !self.rustwave_url.starts_with("http://") && !self.rustwave_url.starts_with("https://") {
            return Err(anyhow::anyhow!(
                "CONFIG ERROR: rustwave_url must begin with http:// or https://, got: {}",
                self.rustwave_url
            ));
        }
        Ok(())
    }
}

/// Update `forum_name` and `site_subtitle` in `settings.toml` in-place,
/// preserving all other lines and comments.
///
/// Called by the admin site-settings handler so that changes made via the
/// panel are reflected in the file and survive a restart without the operator
/// needing to hand-edit `settings.toml`.
///
/// If the key is not yet present in the file the function is a no-op for that
/// key (it won't append new lines — the file is only updated if the key already
/// exists). On a fresh install `generate_settings_file_if_missing` always
/// writes both keys, so this is only a concern for manually-crafted files.
pub fn update_settings_file_site_names(forum_name: &str, site_subtitle: &str) {
    // Escape backslash and double-quote, then wrap in double quotes.
    fn toml_quote(s: &str) -> String {
        let inner = s.replace('\\', "\\\\").replace('"', "\\\"");
        format!("\"{inner}\"")
    }
    let path = settings_file_path();
    let content = match std::fs::read_to_string(&path) {
        Ok(c) => c,
        Err(e) => {
            tracing::warn!(
                target: "config",
                path = %path.display(),
                error = %e,
                "Could not read settings.toml for update"
            );
            return;
        }
    };
    // Replace the value portion of `key = "..."` lines while preserving
    // indentation, comments on the same line, and surrounding whitespace.
    // We use a simple line-by-line scan so that file comments are untouched.
    let trailing_newline = content.ends_with('\n');
    let updated: Vec<String> = content
        .lines()
        .map(|line| {
            // Match `forum_name = ...` (possibly with surrounding spaces).
            if line.trim_start().starts_with("forum_name") && line.contains('=') {
                return format!("forum_name = {}", toml_quote(forum_name));
            }
            if line.trim_start().starts_with("site_subtitle") && line.contains('=') {
                return format!("site_subtitle = {}", toml_quote(site_subtitle));
            }
            line.to_string()
        })
        .collect();
    let mut out = updated.join("\n");
    if trailing_newline {
        out.push('\n');
    }
    // Atomic write: write to a temp file in the same directory, then rename
    // over the target. This prevents a partial write from corrupting settings.toml
    // if the process is killed mid-write (rename(2) is atomic on POSIX).
    let dir = path.parent().unwrap_or_else(|| std::path::Path::new("."));
    match tempfile::Builder::new()
        .prefix(".settings_")
        .suffix(".tmp")
        .tempfile_in(dir)
    {
        Err(e) => {
            tracing::warn!(
                target: "config",
                path = %path.display(),
                error = %e,
                "Could not create temp file for settings.toml update"
            );
        }
        Ok(mut tmp) => {
            use std::io::Write as _;
            let write_result = tmp
                .write_all(out.as_bytes())
                .and_then(|()| tmp.as_file().sync_all());
            if let Err(e) = write_result {
                tracing::warn!(
                    target: "config",
                    path = %path.display(),
                    error = %e,
                    "Could not write settings.toml temp file"
                );
            } else if let Err(e) = tmp.persist(&path) {
                tracing::warn!(
                    target: "config",
                    path = %path.display(),
                    error = %e.error,
                    "Could not atomically replace settings.toml"
                );
            }
        }
    }
}

// ─── Cookie secret rotation check ────────────────────────────────────────────
/// Check whether the `cookie_secret` has changed since the last run by comparing
/// a SHA-256 hash stored in the DB against the currently loaded secret.
///
/// Called once at startup after the DB pool is ready.
/// If the secret has rotated, all IP-based bans become invalid — warn loudly.
/// On first run (no stored hash), silently stores the current hash and returns.
pub fn check_cookie_secret_rotation(conn: &rusqlite::Connection) {
    use sha2::{Digest, Sha256};
    const KEY: &str = "cookie_secret_hash";
    let current_hash = {
        let mut h = Sha256::new();
        h.update(CONFIG.cookie_secret.as_bytes());
        hex::encode(h.finalize())
    };
    let stored = conn
        .query_row(
            "SELECT value FROM site_settings WHERE key = ?1",
            rusqlite::params![KEY],
            |r| r.get::<_, String>(0),
        )
        .ok();
    if let Some(ref h) = stored {
        if h == &current_hash {
            return; // Secret unchanged — nothing to do.
        }
        tracing::warn!(
            "SECURITY WARNING: cookie_secret has changed since the last run. \
             All IP-based bans are now invalid because all IP hashes have changed. \
             If this was unintentional, restore the previous cookie_secret from \
             settings.toml. If intentional, consider running: \
             DELETE FROM bans; DELETE FROM ban_appeals;"
        );
    }
    // First run (None) or rotated secret (Some) — store the current hash.
    let _ = conn.execute(
        "INSERT INTO site_settings (key, value) VALUES (?1, ?2)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        rusqlite::params![KEY, current_hash],
    );
}

// ─── Env helpers ──────────────────────────────────────────────────────────────
fn env_str(key: &str, default: &str) -> String {
    env::var(key).unwrap_or_else(|_| default.to_string())
}

fn env_parse<T: std::str::FromStr>(key: &str, default: T) -> T {
    env::var(key)
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(default)
}

fn env_bool(key: &str, default: bool) -> bool {
    env::var(key)
        .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
        .unwrap_or(default)
}
