// models.rs — plain data structs that map 1:1 to database rows.
// No ORM magic; fields match column names for easy rusqlite mapping.
//
// NOTE: When writing rusqlite FromRow impls for wide structs like Board (18+
// fields), prefer named-column access (`row.get("col")?`) over positional
// indices to avoid silent mis-binding when columns are reordered.

use serde::{Deserialize, Serialize};

// ─── Media type classification ────────────────────────────────────────────────

/// Classifies an uploaded file as image, video, or audio.
/// Stored as a TEXT column in posts ("image", "video", "audio").
///
/// The serde `rename_all = "lowercase"` representation **must** stay in sync
/// with `as_str()` / `from_db_str()`.  Add a round-trip unit test whenever a
/// new variant is introduced.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MediaType {
    Image,
    Video,
    Audio,
}

impl MediaType {
    /// Infer `MediaType` from a MIME type string.
    #[must_use]
    pub fn from_mime(mime: &str) -> Option<Self> {
        if mime.starts_with("image/") {
            Some(Self::Image)
        } else if mime.starts_with("video/") {
            Some(Self::Video)
        } else if mime.starts_with("audio/") {
            Some(Self::Audio)
        } else {
            None
        }
    }

    /// Infer `MediaType` from a file extension (lowercase, no dot).
    /// Used during the backfill migration for pre-existing posts.
    #[must_use]
    #[allow(dead_code)]
    pub fn from_ext(ext: &str) -> Option<Self> {
        match ext {
            "jpg" | "jpeg" | "png" | "gif" | "webp" | "bmp" | "tiff" | "tif" | "svg" => {
                Some(Self::Image)
            }
            "mp4" | "webm" => Some(Self::Video),
            "mp3" | "ogg" | "flac" | "wav" | "m4a" | "aac" | "opus" => Some(Self::Audio),
            _ => None,
        }
    }

    /// Serialise to the TEXT value stored in the database.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::Image => "image",
            Self::Video => "video",
            Self::Audio => "audio",
        }
    }

    /// Deserialise from the TEXT value stored in the database.
    #[must_use]
    pub fn from_db_str(s: &str) -> Option<Self> {
        match s {
            "image" => Some(Self::Image),
            "video" => Some(Self::Video),
            "audio" => Some(Self::Audio),
            _ => None,
        }
    }
}

impl std::fmt::Display for MediaType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// A board, e.g. /tech/ — Technology
#[derive(Debug, Clone, Serialize, Deserialize)]
#[allow(clippy::struct_excessive_bools)]
pub struct Board {
    pub id: i64,
    pub short_name: String, // "tech" (no slashes)
    pub name: String,       // "Technology"
    pub description: String,
    pub nsfw: bool,
    pub max_threads: i64,
    pub bump_limit: i64,
    pub allow_images: bool, // per-board image upload toggle (default: true)
    pub allow_video: bool,  // per-board video upload toggle (default: true)
    pub allow_audio: bool,  // per-board audio upload toggle (default: true)
    pub allow_tripcodes: bool,
    pub allow_editing: bool,   // per-board post editing toggle (default: off)
    pub edit_window_secs: i64, // seconds users can edit their posts (0 = use board default 300)
    pub allow_archive: bool,   // when true, overflow threads are archived instead of deleted
    pub allow_video_embeds: bool, // per-board inline video embed unfurling (YouTube/Invidious/Streamable)
    pub allow_captcha: bool,      // per-board PoW CAPTCHA on new threads only (hashcash-style)
    pub post_cooldown_secs: i64,  // seconds a user must wait between posts (0 = disabled)
    pub created_at: i64,          // Unix timestamp
}

/// A thread (the OP post + its replies share this record for metadata)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Thread {
    pub id: i64,
    pub board_id: i64,
    pub subject: Option<String>,
    pub created_at: i64,
    pub bumped_at: i64,
    pub locked: bool,
    pub sticky: bool,
    pub archived: bool,
    pub reply_count: i64,
    pub image_count: i64,
    // Joined from posts (OP's body/image for catalog previews)
    pub op_body: Option<String>,
    pub op_file: Option<String>,
    pub op_thumb: Option<String>,
    pub op_name: Option<String>,
    pub op_tripcode: Option<String>,
    pub op_id: Option<i64>,
}

/// A single post (OP or reply)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Post {
    pub id: i64,
    pub thread_id: i64,
    pub board_id: i64,
    pub name: String,
    pub tripcode: Option<String>,
    pub subject: Option<String>,
    pub body: String,
    pub body_html: String, // pre-rendered HTML (greentext, links, >>refs)
    /// SHA-256(IP + secret). `None` for gateway-inserted federation posts
    /// which have no inbound client IP.
    pub ip_hash: Option<String>,
    pub file_path: Option<String>,
    pub file_name: Option<String>,
    pub file_size: Option<i64>,
    pub thumb_path: Option<String>,
    pub mime_type: Option<String>,
    /// Explicit media classification — set on all new posts; backfilled for old ones.
    pub media_type: Option<MediaType>,
    /// Secondary audio file for image+audio combo posts (audio path only).
    pub audio_file_path: Option<String>,
    pub audio_file_name: Option<String>,
    pub audio_file_size: Option<i64>,
    pub audio_mime_type: Option<String>,
    pub created_at: i64,
    pub deletion_token: String,
    pub is_op: bool,
    /// Set when the post body has been edited; None means never edited.
    pub edited_at: Option<i64>,
}

/// Admin user record
#[derive(Debug, Clone, Serialize)]
#[allow(dead_code)]
pub struct AdminUser {
    pub id: i64,
    pub username: String,
    /// Excluded from Serialize in practice — be careful not to expose this.
    pub password_hash: String,
    pub created_at: i64,
}

/// Active admin session
#[derive(Debug, Clone, Serialize)]
#[allow(dead_code)]
pub struct AdminSession {
    pub id: String,
    pub admin_id: i64,
    pub created_at: i64,
    pub expires_at: i64,
}

/// A banned IP hash
#[derive(Debug, Clone, Serialize)]
pub struct Ban {
    pub id: i64,
    pub ip_hash: String,
    pub reason: Option<String>,
    pub expires_at: Option<i64>,
    #[allow(dead_code)]
    pub created_at: i64,
}

/// A word filter rule
#[derive(Debug, Clone, Serialize)]
pub struct WordFilter {
    pub id: i64,
    pub pattern: String,
    pub replacement: String,
}

/// Board with live thread count, used on the home page
#[derive(Debug, Clone, Serialize)]
pub struct BoardStats {
    pub board: Board,
    pub thread_count: i64,
}

/// Summary used on board index: thread + its last few reply counts
#[derive(Debug, Clone, Serialize)]
pub struct ThreadSummary {
    pub thread: Thread,
    /// Latest N replies (for board index preview)
    pub preview_posts: Vec<Post>,
    /// How many replies are hidden (total - preview shown)
    pub omitted: i64,
}

/// Form data for posting a new thread or reply (parsed from multipart)
#[derive(Debug, Default, Deserialize)]
#[allow(dead_code)]
pub struct PostForm {
    pub name: String,
    pub subject: String,
    pub body: String,
    pub deletion_token: String,
    // File fields are handled separately in multipart parsing
}

/// Form data for deleting a post
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct DeleteForm {
    pub post_id: i64,
    pub deletion_token: String,
    pub board: String,
}

/// Admin ban form
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct BanForm {
    pub ip_hash: String,
    pub reason: String,
    pub duration_hours: Option<i64>,
}

/// Admin login form
#[derive(Debug, Deserialize)]
#[allow(dead_code)]
pub struct LoginForm {
    pub username: String,
    pub password: String,
}

/// A poll attached to a thread's OP
#[derive(Debug, Clone, Serialize)]
#[allow(dead_code)]
pub struct Poll {
    pub id: i64,
    pub thread_id: i64,
    pub question: String,
    pub expires_at: i64,
    pub created_at: i64,
}

/// A single poll option with live vote count (joined from `poll_votes`)
#[derive(Debug, Clone, Serialize)]
#[allow(dead_code)]
pub struct PollOption {
    pub id: i64,
    pub poll_id: i64,
    pub text: String,
    pub position: i64,
    pub vote_count: i64,
}

/// Full poll data passed to templates
#[derive(Debug, Clone, Serialize)]
pub struct PollData {
    pub poll: Poll,
    pub options: Vec<PollOption>,
    pub total_votes: i64,
    /// Which `option_id` this user voted for, if any
    pub user_voted_option: Option<i64>,
    /// true when `expires_at` <= now
    pub is_expired: bool,
}

/// Search query
#[derive(Debug, Deserialize)]
pub struct SearchQuery {
    pub q: String,
    #[serde(default = "default_page")]
    pub page: i64,
}

const fn default_page() -> i64 {
    1
}

/// Pagination helper
#[derive(Debug, Clone, Serialize)]
pub struct Pagination {
    pub page: i64,
    pub per_page: i64,
    pub total: i64,
}

impl Pagination {
    /// Create a new Pagination, clamping all values to sane minimums.
    ///
    /// - `page` is clamped to >= 1
    /// - `per_page` is clamped to >= 1 (avoids division by zero)
    /// - `total` is clamped to >= 0
    #[must_use]
    pub fn new(page: i64, per_page: i64, total: i64) -> Self {
        Self {
            page: page.max(1),
            per_page: per_page.max(1),
            total: total.max(0),
        }
    }

    /// Total number of pages. Always returns at least 1 so templates can
    /// safely display "page 1 of 1" even on empty result sets.
    #[must_use]
    #[allow(clippy::arithmetic_side_effects)]
    pub fn total_pages(&self) -> i64 {
        // per_page is guaranteed >= 1 by new(), but defend against manual
        // construction just in case.
        let pp = self.per_page.max(1);
        let t = self.total.max(0);
        ((t + pp - 1) / pp).max(1)
    }

    #[must_use]
    pub fn offset(&self) -> i64 {
        self.page
            .max(1)
            .saturating_sub(1)
            .saturating_mul(self.per_page.max(1))
    }

    #[must_use]
    pub const fn has_prev(&self) -> bool {
        self.page > 1
    }

    #[must_use]
    pub fn has_next(&self) -> bool {
        self.page < self.total_pages()
    }
}

/// Aggregate site-wide statistics shown on the home page.
#[derive(Debug, Clone, Default, Serialize)]
pub struct SiteStats {
    /// Total posts ever made
    pub total_posts: i64,
    /// Total image files ever uploaded
    pub total_images: i64,
    /// Total video files ever uploaded
    pub total_videos: i64,
    /// Total audio files ever uploaded
    pub total_audio: i64,
    /// Total bytes of currently stored files (still on disk)
    pub active_bytes: i64,
}

/// A user-filed report against a post
#[derive(Debug, Clone, Serialize)]
#[allow(dead_code)]
pub struct Report {
    pub id: i64,
    pub post_id: i64,
    pub thread_id: i64,
    pub board_id: i64,
    pub reason: String,
    pub reporter_hash: String,
    pub status: String, // "open" | "resolved"
    pub created_at: i64,
    pub resolved_at: Option<i64>,
    pub resolved_by: Option<i64>,
}

/// Report enriched with context from joined tables (used in admin inbox)
#[derive(Debug, Clone, Serialize)]
pub struct ReportWithContext {
    pub report: Report,
    pub board_short: String,
    /// First 120 chars of the reported post body for preview
    pub post_preview: String,
    /// IP hash of the post's author (for quick ban from the inbox).
    /// `None` for gateway-inserted federation posts which have no client IP.
    pub post_ip_hash: Option<String>,
}

/// A single entry in the moderation action log
#[derive(Debug, Clone, Serialize)]
#[allow(dead_code)]
pub struct ModLogEntry {
    pub id: i64,
    pub admin_id: i64,
    pub admin_name: String,
    /// E.g. "`delete_post`", "ban", "sticky", "lock", "`resolve_report`"
    pub action: String,
    /// "post" | "thread" | "board" | "ban" | "report"
    pub target_type: String,
    pub target_id: Option<i64>,
    pub board_short: String,
    /// Human-readable extra context (reason, post body preview, etc.)
    pub detail: String,
    pub created_at: i64,
}

/// Represents a saved backup file on disk (shown in admin panel).
#[derive(Debug, Clone, Serialize)]
pub struct BackupInfo {
    /// Filename only (no directory path).
    pub filename: String,
    /// Size of the file in bytes.
    pub size_bytes: u64,
    /// Human-readable last-modified timestamp (UTC).
    pub modified: String,
}

/// A user-submitted ban appeal
#[derive(Debug, Clone, Serialize)]
pub struct BanAppeal {
    pub id: i64,
    pub ip_hash: String,
    pub reason: String,
    #[allow(dead_code)]
    pub status: String, // "open" | "dismissed"
    pub created_at: i64,
}

// ─── ChanNet federation snapshot types ───────────────────────────────────────
//
// Defined here (not in chan_net::snapshot) so that src/db/chan_net.rs can
// reference SnapshotPost without creating a layering inversion. chan_net is
// declared in main.rs and is therefore not accessible from the lib crate;
// models.rs is re-exported by lib.rs and is safe to import from anywhere.
//
// chan_net::snapshot re-exports these types so that all existing call-sites
// (snapshot::SnapshotPost, etc.) continue to compile without change.

/// A single board entry in a federation snapshot.
/// `id` is the board's `short_name` (e.g. "tech", "b").
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SnapshotBoard {
    pub id: String,
    pub title: String,
}

/// A single post in a federation snapshot.
///
/// SECURITY: Text content only. File paths, MIME types, thumbnail paths, and
/// binary data must NEVER be added to this struct.
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SnapshotPost {
    pub post_id: u64,
    pub board: String,
    pub author: String,
    pub content: String,
    pub timestamp: u64,
}

/// Metadata block written into every federation snapshot ZIP.
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SnapshotMetadata {
    pub generated_at: u64,
    pub rustchan_version: String,
    pub post_count: u64,
    pub tx_id: uuid::Uuid,
    pub signature: Option<String>,
    // Delta fields — always None / false in full federation snapshots.
    pub since: Option<u64>,
    pub is_delta: bool,
    pub includes_archive: bool,
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── MediaType serde ↔ DB string parity ────────────────────────────────

    #[test]
    #[allow(clippy::expect_used)]
    fn media_type_serde_matches_db_str() {
        for mt in [MediaType::Image, MediaType::Video, MediaType::Audio] {
            let json =
                serde_json::to_string(&mt).expect("MediaType always serialises to a JSON string");
            let json_str = json.trim_matches('"');
            assert_eq!(
                mt.as_str(),
                json_str,
                "as_str() and serde disagree for {mt:?}"
            );
            assert_eq!(
                MediaType::from_db_str(json_str),
                Some(mt.clone()),
                "from_db_str() round-trip failed for {mt:?}"
            );
        }
    }

    #[test]
    fn media_type_display_matches_as_str() {
        for mt in [MediaType::Image, MediaType::Video, MediaType::Audio] {
            assert_eq!(format!("{mt}"), mt.as_str());
        }
    }

    #[test]
    fn media_type_from_mime() {
        assert_eq!(MediaType::from_mime("image/png"), Some(MediaType::Image));
        assert_eq!(MediaType::from_mime("video/mp4"), Some(MediaType::Video));
        assert_eq!(MediaType::from_mime("audio/ogg"), Some(MediaType::Audio));
        assert_eq!(MediaType::from_mime("application/json"), None);
    }

    #[test]
    fn media_type_from_ext() {
        assert_eq!(MediaType::from_ext("jpg"), Some(MediaType::Image));
        assert_eq!(MediaType::from_ext("mp4"), Some(MediaType::Video));
        assert_eq!(MediaType::from_ext("flac"), Some(MediaType::Audio));
        assert_eq!(MediaType::from_ext("exe"), None);
    }

    // ── Pagination ────────────────────────────────────────────────────────

    #[test]
    fn pagination_clamps_inputs() {
        let p = Pagination::new(0, 0, -5);
        assert_eq!(p.page, 1);
        assert_eq!(p.per_page, 1);
        assert_eq!(p.total, 0);
    }

    #[test]
    fn pagination_total_pages_at_least_one() {
        let p = Pagination::new(1, 10, 0);
        assert_eq!(p.total_pages(), 1);
    }

    #[test]
    fn pagination_total_pages_normal() {
        assert_eq!(Pagination::new(1, 10, 1).total_pages(), 1);
        assert_eq!(Pagination::new(1, 10, 10).total_pages(), 1);
        assert_eq!(Pagination::new(1, 10, 11).total_pages(), 2);
        assert_eq!(Pagination::new(1, 10, 20).total_pages(), 2);
        assert_eq!(Pagination::new(1, 10, 21).total_pages(), 3);
    }

    #[test]
    fn pagination_offset() {
        assert_eq!(Pagination::new(1, 10, 100).offset(), 0);
        assert_eq!(Pagination::new(2, 10, 100).offset(), 10);
        assert_eq!(Pagination::new(3, 25, 100).offset(), 50);
    }

    #[test]
    fn pagination_offset_clamped_for_bad_page() {
        // Even if someone bypasses new() and manually sets page = -1
        let p = Pagination {
            page: -1,
            per_page: 10,
            total: 50,
        };
        assert_eq!(p.offset(), 0);
    }

    #[test]
    fn pagination_has_prev_and_next() {
        let p = Pagination::new(1, 10, 30);
        assert!(!p.has_prev());
        assert!(p.has_next());

        let p = Pagination::new(2, 10, 30);
        assert!(p.has_prev());
        assert!(p.has_next());

        let p = Pagination::new(3, 10, 30);
        assert!(p.has_prev());
        assert!(!p.has_next());
    }

    #[test]
    fn pagination_single_page() {
        let p = Pagination::new(1, 10, 5);
        assert!(!p.has_prev());
        assert!(!p.has_next());
        assert_eq!(p.total_pages(), 1);
    }

    #[test]
    fn pagination_empty_results() {
        let p = Pagination::new(1, 10, 0);
        assert!(!p.has_prev());
        assert!(!p.has_next());
        assert_eq!(p.total_pages(), 1);
        assert_eq!(p.offset(), 0);
    }
}
